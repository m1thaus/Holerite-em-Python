### Holerite eletrônico

def calcular_holerite():
    print("=== HOLERITE ===")
    

## Informações do funcionário: desconto, salario bruto etc.
    nome = input("Digite o nome do funcionário: ")
    cargo = input("Digite o cargo: ")
    salario_bruto = float(input("Digite o salário bruto: "))
    inss = salario_bruto * 0.11  # 11% de desconto para INSS
    irrf = salario_bruto * 0.075 if salario_bruto > 1903.98 else 0  # Simples cálculo de IRRF
    descontos = inss + irrf
    salario_liquido = salario_bruto - descontos
    
## Imprimir os resultados dos calcs.

    print("\n=== HOLERITE DO FUNCIONÁRIO ===")
    print(f"Nome: {nome}")
    print(f"Cargo: {cargo}")
    print(f"Salário Bruto: R$ {salario_bruto:.2f}")
    print(f"INSS (11%): R$ {inss:.2f}")
    print(f"IRRF (7.5% se aplicável): R$ {irrf:.2f}")
    print(f"Total de Descontos: R$ {descontos:.2f}")
    print(f"Salário Líquido: R$ {salario_liquido:.2f}")

if __name__ == "__main__":
    calcular_holerite()
